﻿using System;
using MbUnit.Framework;
using Rhino.Commons;
using Rhino.Commons.NHibernate;
using Stock.Core.Domain;
using NHibernate.Exceptions;

namespace Stock.Test
{
    [TestFixture]
    public class CompanyFixture : BasePersistanceFixture
    {
        [Test]
        public void CanSaveCompany()
        {
            Company company = SaveNewMSZCompany();
            
            UnitOfWork.Current.TransactionalFlush();
            UnitOfWork.CurrentSession.Evict(company);

            Company fromDb = Repository<Company>.Get(company.ID); //get

            Assert.AreNotSame(company, fromDb);
            Assert.AreEqual("test name of company", fromDb.Name);
            Assert.AreEqual(company.ID, fromDb.ID);

            Console.WriteLine("-----------------------------------------------------------------");
        }

        //[Test]
        //public void AddTheSameCompany()
        //{
        //    Company company = CreateNewCompany();
        //    Repository<Company>.Save(company); //save

        //    Company company2 = CreateNewCompany();
        //    Repository<Company>.Save(company2); //save
        //}

        [Test]
        public void CantFindCompany()
        {
            Company not = Repository<Company>.Get("dup"); //get
            Assert.IsNull(not);
        }

        public static Company SaveNewMSZCompany()
        {
            Company c = new Company("MSZ");
            c.Name = "test name of company";

            Repository<Company>.SaveOrUpdate(c); //save

            return c;
        }

     

    }
}