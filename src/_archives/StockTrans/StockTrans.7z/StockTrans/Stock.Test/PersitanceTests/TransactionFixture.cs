﻿using System;
using System.Collections;
using System.Collections.Generic;
using MbUnit.Framework;
using Rhino.Commons;
using Rhino.Commons.NHibernate;
using Stock.Core.Domain;
using NHibernate.Exceptions;
using Stock.Core.Facade;

namespace Stock.Test
{
    [TestFixture]
    public class TransactionFixture : BasePersistanceFixture
    {
        [Test]
        public void CanSaveTransaction()
        {
            //saving MSZ
            CompanyFixture.SaveNewMSZCompany();
            GroupFixture.CreateNewTransactionGroup();

            Transaction tran = CreateNewTransaction(1);
            
            
            UnitOfWork.Current.TransactionalFlush();
            UnitOfWork.CurrentSession.Evict(tran);

            Transaction fromDb = Repository<Transaction>.Get(tran.ID); //get

            Assert.AreNotSame(tran, fromDb);
            Assert.AreEqual(10, fromDb.Amount);
            Assert.AreEqual(tran.ID, fromDb.ID);

            Console.WriteLine("-----------------------------------------------------------------");
        }

        [Test]
        [ExpectedException(typeof(Exception))]
        public void CannotSaveTransaction()
        {
            Transaction tran = CreateNewTransaction(1);
            Assert.AreEqual(0, tran.ID);

            TransactionController controller = new TransactionController();
            controller.AddNewTransaction(1,100,"MSZ");
            //
            UnitOfWork.Current.TransactionalFlush();
            UnitOfWork.CurrentSession.Evict(tran);
        }

        public static Transaction CreateNewTransaction(int groupId)
        {
            Transaction t = new Transaction();
            t.Amount = 10;
            //t.CompanyId = "MSZ";
            //t.CompanyCode = new Company("MSZ");
            t.Fee = 1;
            t.Price = 2.50M;
            //TransactionGroup g = new TransactionGroup();
            //g.CompanyId = "MSZ";
            //g.Compleated = false;
            //g.Gain = 0;

            //g = Repository<TransactionGroup>.Save(g);
            t.GroupId = groupId;

            Assert.AreEqual(0, t.ID);
            t = Repository<Transaction>.Save(t); //save

            return t;
        }

        [Test]
        public void GetAllTransactions()
        {
            //CompanyFixture.SaveNewMSZCompany();
            ////
            //Transaction tran = CreateNewTransaction();
            //Repository<Transaction>.Save(tran); //save
            CanSaveTransaction();

            TransactionController controller = new TransactionController();
            ICollection<Transaction> transactions = controller.GetAllTransaction();
            Assert.IsNotEmpty((ICollection)transactions);
        }

    }
}