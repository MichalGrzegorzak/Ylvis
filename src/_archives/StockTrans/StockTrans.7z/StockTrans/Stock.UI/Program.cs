﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Repository.Hierarchy;
using NHibernate;
using NHibernate.Tool.hbm2ddl;
using Rhino.Commons;
using NHibernate.Cfg;
using Stock.Forms;

namespace Stock
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            EnableNhibernateLogging();
            CreateDatabase();
            FirstUseOfRepository();

            Form f = new CompanyForm();
            f.Show();

            Application.Run(new TransactionsForm());
        }

        private static void EnableNhibernateLogging()
        {
            IAppender fileApp = null;
            Hierarchy hierarchy = (Hierarchy)LogManager.GetRepository();
            foreach (IAppender app in hierarchy.Root.Appenders)
            {
                if (app is RollingFileAppender
                    && app.Name == "nHibernateAppender")
                {
                    fileApp = app;
                }
            }

            //turn on log4net logging (and supress output to console)
            BasicConfigurator.Configure(fileApp);
        }

        private static void CreateDatabase()
        {
            try
            {
                Configuration cfg = new Configuration().Configure(@"hibernate.cfg.xml"); //must be in root dir
                ISessionFactory factory = cfg.BuildSessionFactory();
                
                //new SchemaExport(cfg).Create(true, true); // creates structure at database (Stock)

                RhinoContainer container = new RhinoContainer(".\\config\\Windsor.config");
                IoC.Initialize(container);

                IoC.Container.Kernel.AddComponentInstance("nhibernate_cfg", cfg);
                IoC.Resolve<IUnitOfWorkFactory>().Init();
            }
            catch (Exception e)
            {
                System.Console.WriteLine(e);
                throw e;
            }
        }

        private static void FirstUseOfRepository()
        {
            string id = "ALFKI";
            //PaymentService service = new PaymentService();
            //Customer c = service.Get(id);
        }
    }
}
