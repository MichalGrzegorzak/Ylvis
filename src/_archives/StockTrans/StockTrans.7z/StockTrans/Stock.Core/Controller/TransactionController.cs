﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NHibernate;
using Rhino.Commons;
using Stock.Core.Domain;
using Order=NHibernate.Criterion.Order;
using NHibernate.Criterion;
using System.Data.SqlClient;

namespace Stock.Core.Facade
{
    public class TransactionController 
    {
        public TransactionController()
        {
        }

        public Transaction AddNewTransaction(int quantity, decimal price, string symbol)
        {
            TransactionGroup group = new TransactionGroup();
            group.CompanyId = symbol;
            group.Compleated = false;
            group.Gain = 0;
            
            Transaction t = new Transaction();
            t.Amount = quantity;
            t.Price = price;
            t.Fee = 0.4M;
            //t.Date = data;

            //checking if company symbol exists in table, if not then we must add it
            CompanyController c = new CompanyController();
            Company company = c.GetCompany(symbol);
            if (company == null)
            {
                c.AddNewCompany(symbol, "brak");
            }

            //saving group & transaction
            try
            {
                group = Repository<TransactionGroup>.Save(group);
                t.GroupId = group.ID;
                t = Repository<Transaction>.Save(t);
                UnitOfWork.Current.TransactionalFlush();
            }
            catch (Exception ex)
            {
                UnitOfWork.CurrentSession.Clear();
                return null;
            }
            
            //t = Repository<Transaction>.Get(t.ID);
            return t;
        }

        public Transaction GetTransaction(int id)
        {
            return Repository<Transaction>.Get(id);
        }

        public ICollection<Transaction> GetAllTransaction()
        {
            DetachedCriteria criteria = DetachedCriteria.For<Transaction>();
                //.Add(Expression.Eq("Customer", customer))
                //.CreateCriteria("Operation")
                //.Add(Expression.Eq("Name", operation));
                
            ICollection <Transaction> results = null;
            results = Repository<Transaction>.FindAll(0, 100, new Order("ID", true));
            return results;
        }

        

    }
}
