﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NHibernate;
using Rhino.Commons;
using Stock.Core.Domain;
using Order=NHibernate.Criterion.Order;
using NHibernate.Criterion;
using System.Data.SqlClient;

namespace Stock.Core.Facade
{
    public class GroupController 
    {
        public GroupController()
        {
        }

        //public TransactionGroup AddNewGroup(string companySymbol)
        //{
        //    TransactionGroup g = new TransactionGroup();
        //    g.CompanyId = companySymbol;
        //    g.Compleated = false;
        //    g.Gain = 0;

        //    try
        //    {
        //        Repository<TransactionGroup>.Save(g);
        //        UnitOfWork.Current.TransactionalFlush();
        //    }
        //    catch (Exception ex)
        //    {
        //        UnitOfWork.CurrentSession.Clear();
        //        return null;
        //    }

        //    return g;
        //}

        public TransactionGroup GetGroup(int groupId)
        {
            return Repository<TransactionGroup>.Get(groupId);
        }

        public ICollection<TransactionGroup> GetAllGroups()
        {
            DetachedCriteria criteria = DetachedCriteria.For<TransactionGroup>();
                //.Add(Expression.Eq("Customer", customer))
                //.CreateCriteria("Operation")
                //.Add(Expression.Eq("Name", operation));

            ICollection<TransactionGroup> results = null;
            results = Repository<TransactionGroup>.FindAll(0, 100, new Order("ID", true));
            return results;
        }

        public ICollection<Transaction> GetAllTransactionForGroup(int groupId)
        {
            DetachedCriteria criteria = DetachedCriteria.For<TransactionGroup>()
                //.CreateCriteria("ID")
                .Add(Expression.Eq("ID", groupId));
            //.Add(Expression.Eq("Customer", customer))
            //.CreateCriteria("Operation")
            //.Add(Expression.Eq("Name", operation));

            ICollection<Transaction> transactions = null;
            TransactionGroup results = Repository<TransactionGroup>.FindOne(criteria);
            transactions = results.Transactions;
            return transactions;
        }

        public void AssignTransactionsToGroup(IList<Int32> transactionsIDs, int groupId)
        {
            DetachedCriteria criteria = DetachedCriteria.For<Transaction>()
                .Add(Expression.In("ID", transactionsIDs.ToArray()));
            //SimpleExpression where1 = Expression.In("ID", new object[] {1,2});
            //SimpleExpression where2 = Expression.In("ID", 1);
            //foreach (int id in transactionsIDs)
            //{
            //    criteria.Add(Expression.Eq("ID", id));
            //}

            ICollection<Transaction> transactions = Repository<Transaction>.FindAll(criteria);
            foreach(Transaction t in transactions)
            {
                t.GroupId = groupId;
                Repository<Transaction>.SaveOrUpdate(t);
            }

            UnitOfWork.Current.TransactionalFlush();
        }

    }
}
