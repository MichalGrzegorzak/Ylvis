using System;
using System.Collections.Generic;

namespace Stock.Core.Domain
{
    /// <summary>
    /// Order object for NHibernate mapped table Orders.
    /// </summary>
    [Serializable]
    public class Company : DomainObject<System.String>
    {
        //public static readonly string CustomerIDStr = "CustomerID";
        
        private String _Name;
        
        #region Constructor
        public Company()
        {
        }

        public Company(System.String id)
        {
            base.ID = id;
        }
        #endregion

        public virtual System.String Name
        {
         get { return _Name; }
         set { _Name = value; }
        }

        #region Methods
        public override int GetHashCode()
        {
            return ID.GetHashCode();
        }
        #endregion

     }
}
