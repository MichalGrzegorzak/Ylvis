using System;
using System.Collections.Generic;

namespace Stock.Core.Domain
{
    /// <summary>
    /// Employee object for NHibernate mapped table Employees.
    /// </summary>
    [Serializable]
    public class TransactionGroup : DomainObject<System.Int32>
    {
        #region Columns Names
        public static readonly string LastNameStr = "LastName";
        public static readonly string FirstNameStr = "FirstName";
        public static readonly string TitleStr = "Title";
        public static readonly string TitleOfCourtesyStr = "TitleOfCourtesy";
        public static readonly string BirthDateStr = "BirthDate";
        public static readonly string HireDateStr = "HireDate";
        public static readonly string AddressStr = "Address";
        public static readonly string CityStr = "City";
        public static readonly string RegionStr = "Region";
        public static readonly string PostalCodeStr = "PostalCode";
        public static readonly string CountryStr = "Country";
        public static readonly string HomePhoneStr = "HomePhone";
        public static readonly string ExtensionStr = "Extension";
        public static readonly string PhotoStr = "Photo";
        public static readonly string NotesStr = "Notes";
        public static readonly string ReportsToStr = "ReportsTo";
        public static readonly string PhotoPathStr = "PhotoPath";
        #endregion

        #region Fields

       
        private IList<Transaction> _Transactions = new List<Transaction>();

        private String _CompanyId;
        private Company _Company;
        private Decimal? _Gain; //finalny zysk
        private bool _Compleated; //czy grupa jest juz zamknieta

        #endregion

        #region Constructor
        public TransactionGroup()
        {
        }

        public TransactionGroup(System.Int32 id)
        {
            base.ID = id;
        }
        #endregion

        
        public virtual IList<Transaction> Transactions
        {
            get { return _Transactions; }
            set { _Transactions = value; }
        }

        public virtual bool Compleated
        {
            get { return _Compleated; }
            set { _Compleated = value; }
        }

        public virtual Decimal? Gain
        {
            get { return _Gain; }
            set { _Gain = value; }
        }

        public virtual System.String CompanyId
        {
            get { return _CompanyId; }
            set { _CompanyId = value; }
        }

        public virtual Company Company
        {
            get { return _Company; }
            set { _Company = value; }
        }
        

        

        #region Methods
        public override int GetHashCode()
        {
            return ID.GetHashCode();
        }
        #endregion

     }
}
