using System;
using System.Collections.Generic;

namespace Stock.Core.Domain
{
    /// <summary>
    /// Employee object for NHibernate mapped table Employees.
    /// </summary>
    [Serializable]
    public class Transaction : DomainObject<System.Int32>
    {
        public static readonly string LastNameStr = "LastName";
        public static readonly string FirstNameStr = "FirstName";
       

        #region Fields

       
        private Int32 _GroupId;
        private Int32 _Amount;
        private Decimal _Price;
        private Decimal _Fee; //prowizja
        private Decimal _Income; //przychod

        #endregion

        #region Constructor
        public Transaction()
        {
        }

        public Transaction(System.Int32 id)
        {
            base.ID = id;
        }
        #endregion

        public virtual Int32 Amount
        {
            get { return _Amount; }
            set { _Amount = value; }
        }

        public virtual Int32 GroupId
        {
            get { return _GroupId; }
            set { _GroupId = value; }
        }
        

        public virtual Decimal Price
        {
            get { return _Price; }
            set { _Price = value; }
        }

        public virtual Decimal Fee
        {
            get { return _Fee; }
            set { _Fee = value; }
        }

        public virtual Decimal Income
        {
            get { return _Income; }
            set { _Income = value; }
        }

        public string Symbol
        {
            get { return _Group.CompanyId; }
        }

        public int TransGroupId
        {
            get { return _Group.ID; }
        }

        private TransactionGroup _Group;
        public virtual TransactionGroup Group
        {
            get { return _Group; }
            set { _Group = value; }
        }


        #region Methods
        public override int GetHashCode()
        {
            return ID.GetHashCode();
        }
        #endregion

     }
}
